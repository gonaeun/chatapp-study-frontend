import React from "react";
import "./App.css";
import socket from "./server";

function App() {
  return (
    <div>
      <div className="App"></div>
    </div>
  );
}

export default App;
